import pymysql
#connection to database
host = '127.0.0.1'
port = 3306
user = 'root'
password = ''
database = 'python'
def database_connection(host,port, user, password, database):
    try:
        connection = pymysql.connect(host=host, port=port, user=user, password=password, database=database)
        print("database Connected")
        return connection
    except Exception as e:
        print(f"Error connecting to the database: {e}")
        return None
# Function to execute a query and handle errors
def execute_query(connection, query):
    try:
        with connection.cursor() as cursor:
            cursor.execute(query)
            result = cursor.fetchall()
            return result
    except Exception as e:
        print(f"Error executing query: {e}")
        return None
# Function to view the product table
def inventory_show_function(connection):
    query = "SELECT * FROM products;"
    result = execute_query(connection, query)
    if result:
        for row in result:
            print(row)
    else:
        print("Failed to retrieve inventory.")
# Function to view the customer table
def showing_customer_information(connection):
    query = "SELECT * FROM customers;"
    result = execute_query(connection, query)
    if result:
        for row in result:
            print(row)
    else:
        print("Failed to retrieve customer information.")
# Function to view sales records
def show_sales_details(connection):
    query = "SELECT * FROM sales;"
    result = execute_query(connection, query)
    if result:
        for row in result:
            print(row)
    else:
        print("Failed to retrieve sales records.")
# Function to place an order
from Crypto.Cipher import AES
import base64
#AES encryption/decryption functions
def aes_encrypt(text, key):
    cipher = AES.new(key, AES.MODE_ECB)
    return base64.b64encode(cipher.encrypt(text)).decode('utf-8')
def aes_decrypt(encrypted_text, key):
    cipher = AES.new(key, AES.MODE_ECB)
    return cipher.decrypt(base64.b64decode(encrypted_text)).decode('utf-8')
def place_order(connection):
    try:
        # Get user input for order details
        customer_id = input("Enter customer ID: ")
        product_id = input("Enter product ID: ")
        quantity = int(input("Enter quantity: "))

        # Query the product table to get pricing
        product_query = f"SELECT Cost FROM products WHERE ProductID = '{product_id}';"
        product_result = execute_query(connection, product_query)
        # Query the customer table to get encrypted account information
        customer_query = f"SELECT ID FROM customers WHERE ID = '{customer_id}';"
        customer_result = execute_query(connection, customer_query)
        if product_result and customer_result:
            # Extract relevant information from query results
            cost = product_result[0][0]
            # Calculate total cost
            totalcost = quantity * cost
            # Update the sales table with the new order
            sales_query = f"INSERT INTO sales (customer_id, product_id, quantity, totalcost) " \
                          f"VALUES ('{customer_id}', '{product_id}', {quantity}, {totalcost});"
            execute_query(connection, sales_query)
            connection.commit()
            print("Order placed successfully.")
        else:
            print("Failed to retrieve product or customer information.")
    except Exception as e:
        print(f"Error placing order: {e}")

#re established the connection
connection = pymysql.connect(
    host='127.0.0.1',
    user='root',
    password='',
    database='python',
    port=3306
)
# Main program
if __name__ == "__main__":
    # Constants
    host = '127.0.0.1'
    port=3306
    user = 'root'
    password = ''
    database = 'python'
    # Connect to the database
    db_connection = database_connection(host,port, user, password, database)
    # Menu loop
    while True:
        print("\nOption for you:")
        print("Press 1 for show inventory")
        print("press 2 for show customer information")
        print("press 3 for show sales details")
        print("press 4 for do an order")
        print("press 5 for Quit")
        choice = input("Enter your choice: ").upper()

        if choice == '1':
            inventory_show_function(db_connection)
        elif choice == '2':
            showing_customer_information(db_connection)
        elif choice == '3':
            show_sales_details(db_connection)
        elif choice == '4':
            place_order(db_connection)
        elif choice == '5':
            print("Exiting the program.")
            break
        else:
            print("Invalid choice. Please try again.")
